"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import useEmblaCarousel from "embla-carousel-react";
import type { ScrollBodyType } from "embla-carousel";
import { urlFor } from "@/lib/sanity";
import Image from "next/image";

type Testimonial = {
  _id: string;
  clientName: string;
  clientRole?: string;
  clientPhoto?: any;
  quote: string;
  advisor?: { name: string };
};

interface TestimonialSliderProps {
  testimonials: Testimonial[];
  title?: string;
}

type EdgeZone = "left-fast" | "center" | "right-fast";


function getZone(normalizedX: number): EdgeZone {
  // Krajných 20 % ovláda rýchly pohyb, stredných 60 % carousel zastaví.
  if (normalizedX < -0.6) return "left-fast";
  if (normalizedX > 0.6) return "right-fast";
  return "center";
}

export default function TestimonialSlider({ testimonials, title }: TestimonialSliderProps) {
  const [shuffled, setShuffled] = useState<Testimonial[]>([]);
  const [activeIndex, setActiveIndex] = useState(0);
  const currentZoneRef = useRef<EdgeZone | null>(null);
  const isDesktopPointerRef = useRef(false);
  const defaultScrollBodyRef = useRef<ScrollBodyType | null>(null);

  useEffect(() => {
    if (!testimonials?.length) return;
    const arrayToShuffle = [...testimonials];
    for (let i = arrayToShuffle.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arrayToShuffle[i], arrayToShuffle[j]] = [arrayToShuffle[j], arrayToShuffle[i]];
    }
    setShuffled(arrayToShuffle);
    setActiveIndex(0);
  }, [testimonials]);

  const items = shuffled.length > 0 ? shuffled : testimonials;


  const [emblaRef, emblaApi] = useEmblaCarousel(
    {
      loop: items.length > 1,
      dragFree: true,
      align: "center",
      containScroll: false,
      skipSnaps: true,
    },
  );

  const stopDesktopScroll = useCallback(() => {
    if (!emblaApi) return;
    const engine = emblaApi.internalEngine();
    engine.animation.stop();

    if (defaultScrollBodyRef.current) {
      engine.scrollBody = defaultScrollBodyRef.current;
      defaultScrollBodyRef.current = null;
    }
  }, [emblaApi]);

  const startDesktopScroll = useCallback(
    (direction: "forward" | "backward", speed = 0.45) => {
      if (!emblaApi) return;
      const engine = emblaApi.internalEngine();

      engine.animation.stop();
      if (!defaultScrollBodyRef.current) {
        defaultScrollBodyRef.current = engine.scrollBody;
      }

      const directionSign = direction === "forward" ? -1 : 1;
      const velocity = directionSign * speed;
      let rawLocation = engine.location.get();
      let rawLocationPrevious = rawLocation;
      let scrollDirection = 0;
      const noop = (): ScrollBodyType => body;

      const body: ScrollBodyType = {
        direction: () => scrollDirection,
        duration: () => -1,
        velocity: () => velocity,
        settled: () => false,
        seek: () => {
          engine.previousLocation.set(engine.location);
          rawLocation += velocity;
          engine.location.add(velocity);
          engine.target.set(engine.location);

          scrollDirection = Math.sign(rawLocation - rawLocationPrevious);
          rawLocationPrevious = rawLocation;

          const currentIndex = engine.scrollTarget.byDistance(0, false).index;
          if (engine.index.get() !== currentIndex) {
            engine.indexPrevious.set(engine.index.get());
            engine.index.set(currentIndex);
            emblaApi.emit("select");
          }

          return body;
        },
        useBaseFriction: noop,
        useBaseDuration: noop,
        useFriction: noop,
        useDuration: noop,
      };

      engine.scrollBody = body;
      engine.animation.start();
    },
    [emblaApi],
  );

  useEffect(() => {
    const media = window.matchMedia("(hover: hover) and (pointer: fine)");
    const update = () => {
      isDesktopPointerRef.current = media.matches;
      currentZoneRef.current = null;
      if (media.matches) {
        startDesktopScroll("forward");
      } else {
        stopDesktopScroll();
      }
    };

    update();
    media.addEventListener("change", update);
    return () => {
      media.removeEventListener("change", update);
      stopDesktopScroll();
    };
  }, [startDesktopScroll, stopDesktopScroll]);

  useEffect(() => {
    if (items.length <= 1) return;

    const intervalId = window.setInterval(() => {
      setActiveIndex((currentIndex) => {
        let nextIndex = currentIndex;
        while (nextIndex === currentIndex) {
          nextIndex = Math.floor(Math.random() * items.length);
        }
        return nextIndex;
      });
    }, 30_000);

    return () => window.clearInterval(intervalId);
  }, [items.length]);

  const applyZone = useCallback(
    (zone: EdgeZone) => {
      if (!emblaApi || !isDesktopPointerRef.current || currentZoneRef.current === zone) return;

      currentZoneRef.current = zone;

      if (zone === "center") {
        stopDesktopScroll();
        return;
      }

      startDesktopScroll(zone === "left-fast" ? "backward" : "forward", 1.8);
    },
    [emblaApi, startDesktopScroll, stopDesktopScroll],
  );

  if (!testimonials?.length) return null;
  const current = items[activeIndex] ?? items[0];

  return (
    <div className="w-full max-w-5xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden select-none">
      <div className="p-8 md:p-12">
        <h2 className="font-serif text-lg text-gray-900 mb-6 tracking-tight text-center md:text-left">
          {title || "Čo o nás povedali naši klienti"}
        </h2>

        <div className="max-w-3xl mx-auto flex flex-col items-center text-center">
          <span className="font-serif text-6xl text-brand-teal/20 h-8 block">“</span>

          <div className="min-h-[140px] flex items-center justify-center mt-4">
            <p key={current._id} className="text-base md:text-lg text-slate-700 italic leading-relaxed animate-fade-in">
              {current.quote}
            </p>
          </div>

          <div className="mt-6 min-h-[92px]">
            <p className="text-sm font-bold text-slate-900">{current.clientName}</p>
            {current.clientRole && <p className="text-xs text-slate-400 mt-0.5">{current.clientRole}</p>}
          </div>

          <div
            ref={emblaRef}
            className="relative mt-8 w-full overflow-hidden touch-pan-y"
            onMouseEnter={() => applyZone("center")}
            onMouseMove={(event) => {
              const rect = event.currentTarget.getBoundingClientRect();
              const normalizedX = ((event.clientX - rect.left) / rect.width) * 2 - 1;
              applyZone(getZone(normalizedX));
            }}
            onMouseLeave={() => {
              currentZoneRef.current = null;
              if (isDesktopPointerRef.current) startDesktopScroll("forward");
            }}
          >
            <div className="flex items-center gap-3 py-3 [backface-visibility:hidden]">
              {items.map((testimonial, index) => {
                const isSelected = index === activeIndex;

                return (
                  <div
                    key={testimonial._id}
                    className="h-16 w-16 flex-[0_0_64px] flex items-center justify-center"
                  >
                    <button
                      type="button"
                      onClick={() => setActiveIndex(index)}
                      className={`relative h-14 w-14 overflow-hidden rounded-full border-2 flex items-center justify-center transition-[opacity,border-color,box-shadow] duration-300 ${
                        isSelected
                          ? "border-brand-teal opacity-100 ring-4 ring-brand-teal/10"
                          : "border-gray-200 opacity-40"
                      }`}
                      aria-label={`Zobraziť referenciu: ${testimonial.clientName}`}
                    >
                      <span
                        className={`absolute inset-0 transition-transform duration-300 ease-out ${
                          isSelected ? "scale-110" : "scale-95"
                        }`}
                      >
                        {testimonial.clientPhoto ? (
                          <Image
                            src={urlFor(testimonial.clientPhoto).width(112).height(112).url()}
                            alt={testimonial.clientName}
                            fill
                            sizes="56px"
                            draggable={false}
                            className="pointer-events-none object-cover"
                          />
                        ) : (
                          <span className="absolute inset-0 flex items-center justify-center text-xs font-bold text-slate-400">
                            {testimonial.clientName.charAt(0)}
                          </span>
                        )}
                      </span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
