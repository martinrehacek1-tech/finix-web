"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Menu, X } from "lucide-react";

const links = [
  { href: "/o-nas", label: "O nás" },
  { href: "/#sluzby", label: "Služby" },
  { href: "/blog", label: "Blog" },
  { href: "/kontakt", label: "Kontakt" },
];

export default function SiteHeader() {
  const [open, setOpen] = useState(false);

  return (
    <header className="relative border-b border-slate-200">
      <div className="flex items-center justify-between px-6 py-4">
        <Link href="/" onClick={() => setOpen(false)}>
          <Image src="/logo_text.png" alt="FINIX" width={120} height={36} priority className="h-8 w-auto" />
        </Link>

        <nav className="hidden md:flex gap-6 text-sm text-slate-600">
          {links.map((l) => (
            <Link key={l.href} href={l.href}>{l.label}</Link>
          ))}
        </nav>

        <button
          onClick={() => setOpen(!open)}
          className="md:hidden p-2 -mr-2 text-brand-navy"
          aria-label={open ? "Zavrieť menu" : "Otvoriť menu"}
        >
          {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {open && (
        <nav className="md:hidden flex flex-col border-t border-slate-200 bg-white px-6 py-4 gap-4 text-sm text-slate-700">
          {links.map((l) => (
            <Link key={l.href} href={l.href} onClick={() => setOpen(false)}>
              {l.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}