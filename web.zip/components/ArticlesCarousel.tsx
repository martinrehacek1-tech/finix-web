"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";

function ArticleCard({ post }: { post: any }) {
  return (
    <Link
      href={`/blog/${post.slug.current}`}
      className="flex-none w-[280px] bg-white border border-slate-100 rounded-2xl p-5 shadow-sm hover:shadow-md hover:border-brand-blue transition duration-300 flex flex-col justify-between select-none group"
    >
      <div>
        <span className="text-[10px] text-brand-teal font-mono uppercase tracking-wider block mb-2">
          {post.category?.title || "Blog"}
        </span>
        <h3 className="text-sm font-bold text-slate-900 leading-snug group-hover:text-brand-blue transition duration-200 line-clamp-3">
          {post.title}
        </h3>
      </div>
      <div className="text-xs text-slate-400 mt-4 flex items-center justify-between">
        <span>Čítať článok</span>
        <span className="text-brand-blue font-bold">→</span>
      </div>
    </Link>
  );
}

export default function ArticlesCarousel({ posts }: { posts: any[] }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [isOverflowing, setIsOverflowing] = useState(false);

  const isHovered = useRef(false);
  const virtualScrollLeft = useRef(0);
  const currentX = useRef(0);
  const targetInteractiveSpeed = useRef(0);
  const currentInteractiveSpeed = useRef(0);

  const autoSpeed = 0.2;
  const maxInteractiveSpeed = 5;
  const easingFactor = 0.6;
  const edgeZonePercentage = 0.2;

  useEffect(() => {
    if (!containerRef.current || !trackRef.current) return;
    setIsOverflowing(trackRef.current.scrollWidth > containerRef.current.clientWidth);
  }, [posts]);

  useEffect(() => {
    if (!containerRef.current || !isOverflowing) return;

    let raf: number;
    const container = containerRef.current;
    virtualScrollLeft.current = container.scrollLeft;

    function updatePhysics() {
      let speedToApply = 0;

      if (isHovered.current) {
        const width = container.clientWidth;
        const mouseX = currentX.current;
        const leftZoneBoundary = width * edgeZonePercentage;
        const rightZoneBoundary = width * (1 - edgeZonePercentage);

        if (mouseX < leftZoneBoundary) {
          const intensity = (leftZoneBoundary - mouseX) / leftZoneBoundary;
          targetInteractiveSpeed.current = -intensity * maxInteractiveSpeed;
        } else if (mouseX > rightZoneBoundary) {
          const intensity = (mouseX - rightZoneBoundary) / (width - rightZoneBoundary);
          targetInteractiveSpeed.current = intensity * maxInteractiveSpeed;
        } else {
          targetInteractiveSpeed.current = 0;
        }

        currentInteractiveSpeed.current += (targetInteractiveSpeed.current - currentInteractiveSpeed.current) * easingFactor;
        if (Math.abs(currentInteractiveSpeed.current) < 0.01) currentInteractiveSpeed.current = 0;
        speedToApply = currentInteractiveSpeed.current;
      } else {
        speedToApply = autoSpeed;
        targetInteractiveSpeed.current = 0;
        currentInteractiveSpeed.current = 0;
      }

      virtualScrollLeft.current += speedToApply;
      container.scrollLeft = Math.round(virtualScrollLeft.current);

      if (trackRef.current) {
        const halfWidth = trackRef.current.scrollWidth / 2;
        if (virtualScrollLeft.current >= halfWidth) {
          virtualScrollLeft.current -= halfWidth;
        } else if (virtualScrollLeft.current <= 0) {
          virtualScrollLeft.current += halfWidth;
        }
        container.scrollLeft = Math.round(virtualScrollLeft.current);
      }

      raf = requestAnimationFrame(updatePhysics);
    }

    raf = requestAnimationFrame(updatePhysics);
    return () => cancelAnimationFrame(raf);
  }, [isOverflowing]);

  if (posts.length === 0) return null;
  const looped = isOverflowing ? [...posts, ...posts] : posts;

  return (
    // Zabalenie do identického kontajnera ako profil (dlaždice)
    <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="p-8 md:p-12">
        
        {/* Interný integrovaný nadpis so zhodným dizajnom a paddingom */}
        <h2 className="font-serif text-2xl text-gray-900 mb-6 tracking-tight">
          Články, ktoré som napísal
        </h2>

        {/* Samotná scrollovacia zóna karuselu */}
        <div
          ref={containerRef}
          className={`overflow-x-auto select-none [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] ${
            isOverflowing ? "cursor-ew-resize" : "flex justify-center"
          }`}
          onMouseEnter={(e) => {
            if (!containerRef.current) return;
            isHovered.current = true;
            virtualScrollLeft.current = containerRef.current.scrollLeft;
            currentX.current = e.clientX - containerRef.current.getBoundingClientRect().left;
          }}
          onMouseMove={(e) => {
            if (!containerRef.current || !isHovered.current) return;
            currentX.current = e.clientX - containerRef.current.getBoundingClientRect().left;
          }}
          onMouseLeave={() => {
            isHovered.current = false;
          }}
        >
          <div ref={trackRef} className="flex gap-4 w-max py-2 px-1">
            {looped.map((post, i) => (
              <ArticleCard key={`${post._id}-${i}`} post={post} />
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}