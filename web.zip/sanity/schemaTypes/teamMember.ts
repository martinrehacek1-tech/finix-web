import { defineField, defineType } from "sanity";

// Toto je formulár, ktorý uvidíš v administrácii pri pridávaní/úprave poradcu.
// Každé "field" nižšie = jeden riadok vo formulári.
export default defineType({
  name: "teamMember",
  title: "Poradca / člen tímu",
  type: "document",
  fields: [
    defineField({
      name: "name",
      title: "Meno a priezvisko",
      type: "string",
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: "slug",
      title: "URL adresa (automaticky z mena)",
      type: "slug",
      options: { source: "name", maxLength: 96 },
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: "titleBefore",
      title: "Titul pred menom (napr. Ing.)",
      type: "string",
    }),

    defineField({
      name: "titleAfter",
      title: "Titul za menom (napr. PhD., MBA)",
      type: "string",
    }),

    defineField({
      name: "photo",
      title: "Fotografia",
      type: "image",
      options: { hotspot: true },
      validation: (rule) => rule.required(),
    }),
    defineField({
      name: "specialization",
      title: "Špecializácia (krátky popis pod menom, napr. Hypotéky, poistenie)",
      type: "string",
      validation: (rule) => rule.required(),
    }),

    defineField({
      name: "position",
      title: "Pozícia (seniorita, napr. Senior Broker, Regionálny riaditeľ)",
      type: "string",
      validation: (rule) => rule.required().error("Zadajte pracovnú pozíciu pre správne zobrazenie štruktúry."),
    }),

    defineField({
      name: "bio",
      title: "O mne (dlhší text na profilovej stránke)",
      type: "text",
      rows: 5,
    }),
    defineField({
      name: "nbsLicense",
      title: "Licencia NBS",
      type: "string",
    }),
    defineField({
      name: "phone",
      title: "Telefón",
      type: "string",
    }),
    defineField({
      name: "email",
      title: "Email",
      type: "string",
    }),
    defineField({
      name: "order",
      title: "Poradie zobrazenia (menšie číslo = vpredu)",
      type: "number",
      initialValue: 100,
    }),
    defineField({
      name: "active",
      title: "Zobraziť na webe",
      type: "boolean",
      initialValue: true,
      description: "Vypni, ak poradca už vo firme nepracuje - zmizne z webu, ale história zostane zachovaná.",
    }),
  ],
  preview: {
    select: { title: "name", subtitle: "specialization", media: "photo" },
  },
});
