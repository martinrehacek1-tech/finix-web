import { client, queries, urlFor } from "@/lib/sanity";
import TeamCarousel from "@/components/TeamCarousel";
import TestimonialSlider from "@/components/TestimonialSlider";
import ServiceIcon from "@/components/ServiceIcon";
import Link from "next/link";
import Image from "next/image";
import SiteHeader from "@/components/SiteHeader";

export const revalidate = 60;

export default async function HomePage() {
  const [settings, team, services, posts, testimonials] = await Promise.all([
    client.fetch(queries.siteSettings),
    client.fetch(queries.teamMembers),
    client.fetch(queries.services),
    client.fetch(queries.recentPosts),
    client.fetch(queries.testimonials),
  ]);

  return (
    <main>
      <SiteHeader />

      <section className="relative px-6 py-14 grid md:grid-cols-2 gap-8 items-start max-w-5xl mx-auto overflow-hidden">
 <div
  aria-hidden="true"
  className="block md:hidden absolute inset-0 pointer-events-none"
  style={{
    backgroundImage: "url('/logo_main.png')",
    backgroundRepeat: "no-repeat",
    backgroundPosition: "center 100%",
    backgroundSize: "150% auto",
    WebkitMaskImage: "linear-gradient(180deg, black 0%, black 35%, transparent 80%)",
    maskImage: "linear-gradient(180deg, black 0%, black 35%, transparent 80%)",
    opacity: 0.07,
  }}
/>       

<div
  aria-hidden="true"
  className="hidden md:block absolute inset-0 pointer-events-none"
  style={{
    backgroundImage: "url('/logo_main.png')",
    backgroundRepeat: "no-repeat",
    backgroundPosition: "120% center",
    backgroundSize: "auto 250%",
    WebkitMaskImage: "linear-gradient(100deg, transparent 0%, transparent 35%, black 75%, black 100%)",
    maskImage: "linear-gradient(100deg, transparent 0%, transparent 35%, black 75%, black 100%)",
    opacity: 0.16,
  }}
/>
        <div className="relative z-10">
          <p className="text-xs tracking-wide text-brand-teal font-medium mb-2">
            FINANČNÉ PORADENSTVO · KOŠICE
          </p>
          <h1 className="font-serif text-4xl leading-tight text-brand-navy mb-4">
            {settings?.heroHeadline || "Vaše financie, jasne zrátané."}
          </h1>
          <p className="text-slate-600 mb-6 max-w-sm">
            {settings?.heroSubtext ||
              "Hypotéky, poistenie a investície bez omáčky. Poradíme presne, čo sa oplatí a prečo."}
          </p>
          <div className="flex gap-3 items-center">
            <Link href="/kontakt" className="bg-brand-blue text-white text-sm px-5 py-2.5 rounded-md">
              Dohodnúť stretnutie
            </Link>
            <Link href="/#sluzby" className="text-sm border-b border-brand-navy">
              Prezrieť služby
            </Link>
          </div>
        </div>
      </section>

     <section className="border-y border-slate-200 py-6 px-4 sm:px-6">
  <div className="max-w-4xl mx-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 text-center gap-x-4 gap-y-6 md:gap-4 items-start">
    
    {/* 1. Štatistika */}
    <div className="col-span-1">
      <p className="font-mono text-xl sm:text-2xl font-medium text-brand-navy tracking-tight">
        {settings?.statClients ?? "1 339"}
      </p>
      <p className="text-[11px] sm:text-xs text-slate-500 mt-1 leading-tight px-1">
        spokojných klientov
      </p>
    </div>

    {/* 2. Štatistika */}
    <div className="col-span-1">
      <p className="font-mono text-xl sm:text-2xl font-medium text-brand-navy tracking-tight">
        {settings?.statFirstHomes ?? "400+"}
      </p>
      <p className="text-[11px] sm:text-xs text-slate-500 mt-1 leading-tight px-1">
        prvé bývanie
      </p>
    </div>

    {/* 3. Štatistika */}
    <div className="col-span-1">
      <p className="font-mono text-xl sm:text-2xl font-medium text-brand-navy tracking-tight">
        {settings?.statMortgageVolume ?? "500M"}
      </p>
      <p className="text-[11px] sm:text-xs text-slate-500 mt-1 leading-tight px-1">
        sprostredkovaný objem hypoték
      </p>
    </div>

    {/* 4. Štatistika */}
    <div className="col-span-1">
      <p className="font-mono text-xl sm:text-2xl font-medium text-brand-teal tracking-tight">
        {settings?.statSavedEur ? `${(settings.statSavedEur / 1_000_000).toFixed(1)}M €` : "46,3M"}
      </p>
      <p className="text-[11px] sm:text-xs text-slate-500 mt-1 leading-tight px-1">
        ušetrené na úrokoch
      </p>
    </div>

    {/* 5. Štatistika – Na malých displejoch sa vycentruje na celú šírku pre vizuálnu rovnováhu */}
    <div className="col-span-2 sm:col-span-1">
      <p className="font-mono text-xl sm:text-2xl font-medium text-brand-navy tracking-tight">
        {settings?.statInvestedVolume ?? "10M"}
      </p>
      <p className="text-[11px] sm:text-xs text-slate-500 mt-1 leading-tight px-1">
        investovaných € v správe
      </p>
    </div>

  </div>
</section>

      <section id="sluzby" className="px-6 py-12 max-w-5xl mx-auto">
        <h2 className="font-serif text-lg text-brand-navy mb-4">S týmto vám pomôžeme</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {services.map((s: any) => (
            <Link
              key={s._id}
              href={`/sluzby/${s.slug.current}`}
              className="group flex flex-col items-center text-center gap-3 bg-white border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-brand-blue transition duration-300"
            >
              <span className="w-12 h-12 rounded-full bg-brand-teal/10 flex items-center justify-center">
                <ServiceIcon name={s.icon} className="w-6 h-6 text-brand-blue" />
              </span>
              <p className="text-sm font-bold text-slate-900">{s.title}</p>
              {s.shortDescription && (
                <p className="text-xs text-slate-500 line-clamp-2">{s.shortDescription}</p>
              )}
            </Link>
          ))}
        </div>
      </section>

      <section className="px-6 py-12 max-w-5xl mx-auto">
        <h2 className="font-serif text-lg text-brand-navy mb-1">Naši odborníci</h2>
        <TeamCarousel members={team} />
      </section>

      <TestimonialSlider testimonials={testimonials} />

      <section className="px-6 py-12 max-w-5xl mx-auto">
        <h2 className="font-serif text-lg text-brand-navy mb-4">Z blogu</h2>
        <div className="divide-y divide-slate-200 border-t border-slate-200">
          {posts.map((p: any) => (
            <Link
              key={p._id}
              href={`/blog/${p.slug.current}`}
              className="flex justify-between items-center py-3 gap-4"
            >
              <span className="text-sm">{p.title}</span>
              <span className="text-xs text-brand-teal font-mono whitespace-nowrap">
                {p.category?.title}
              </span>
            </Link>
          ))}
        </div>
      </section>

      <footer className="bg-brand-navy text-white px-6 py-6 flex items-center justify-between">
        <p className="text-sm">Chcete platiť menej za finančné produkty?</p>
        <Link href="/kontakt" className="bg-brand-teal text-brand-tealDark text-sm px-4 py-2 rounded-md">
          Áno, chcem
        </Link>
      </footer>
    </main>
  );
}