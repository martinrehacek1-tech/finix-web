import { client, queries, urlFor } from "@/lib/sanity";
import { PortableText, PortableTextComponents } from "@portabletext/react";
import SiteHeader from "@/components/SiteHeader";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";

export const revalidate = 60;

export async function generateStaticParams() {
  const posts = await client.fetch(queries.recentPosts);
  return posts.map((p: any) => ({ slug: p.slug.current }));
}

const components: PortableTextComponents = {
  types: {
    image: ({ value }) => (
      <img
        src={urlFor(value).width(1200).fit("max").auto("format").url()}
        alt={value.alt || ""}
        className="w-full h-auto rounded-lg my-6"
      />
    ),
    table: ({ value }) => {
      const rows: string[][] = (value.rawData || "")
        .split("\n")
        .filter((line: string) => line.trim() !== "")
        .map((line: string) =>
          line.includes("\t") ? line.split("\t") : line.split("|").map((c: string) => c.trim())
        );
      return (
        <div className="overflow-x-auto my-6">
          <table className="w-full text-sm border-collapse">
  <tbody>
    {rows.map((row, i) => (
      <tr
        key={i}
        className={
          value.hasHeaderRow && i === 0
            ? "bg-brand-navy text-white"
            : "border-b border-slate-200"
        }
      >
        {row.map((cell, j) => (
          <td key={j} className="px-3 py-2 text-left">
            {cell}
          </td>
        ))}
      </tr>
    ))}
  </tbody>
</table>
        </div>
      );
    },
    callout: ({ value }) => {
      const colorMap: Record<string, string> = {
        green: "bg-brand-teal/10 border-brand-teal",
        blue: "bg-brand-blue/10 border-brand-blue",
        yellow: "bg-amber-100 border-amber-400",
      };
      const cls = colorMap[value.color] || colorMap.green;
      return (
        <div className={`my-6 rounded-lg border-l-4 px-5 py-4 ${cls}`}>
          {value.heading && <p className="font-bold text-brand-navy mb-1">{value.heading}</p>}
          <p className="text-slate-700 text-sm leading-relaxed">{value.text}</p>
        </div>
      );
    },
  },
};

export default async function BlogPostPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const post = await client.fetch(queries.postBySlug, { slug });
  if (!post) return notFound();

  return (
    <main>
      <SiteHeader />

      <article className="px-6 py-14 max-w-2xl mx-auto">
        <p className="text-xs text-brand-teal font-mono mb-3">{post.category?.title}</p>
        <h1 className="font-serif text-3xl text-brand-navy mb-4 leading-tight">{post.title}</h1>

        <div className="flex items-center gap-3 text-sm text-slate-500 mb-8">
          {post.author?.name && (
            <Link href={`/tim/${post.author.slug.current}`} className="hover:text-brand-blue">
              {post.author.name}
            </Link>
          )}
          {post.publishedAt && (
            <span>
              {new Date(post.publishedAt).toLocaleDateString("sk-SK", {
                day: "numeric",
                month: "long",
                year: "numeric",
              })}
            </span>
          )}
        </div>

        {post.coverImage && (
          <div className="relative w-full aspect-video mb-8 rounded-lg overflow-hidden">
            <Image src={urlFor(post.coverImage).width(1200).url()} alt={post.title} fill className="object-cover" />
          </div>
        )}

        <div className="prose prose-slate prose-sm max-w-none">
          <PortableText value={post.body} components={components} />
        </div>
      </article>

      <footer className="bg-brand-navy text-white px-6 py-6 flex items-center justify-between">
        <p className="text-sm">Chcete platiť menej za finančné produkty?</p>
        <Link href="/kontakt" className="bg-brand-teal text-brand-tealDark text-sm px-4 py-2 rounded-md">
          Dohodnúť stretnutie
        </Link>
      </footer>
    </main>
  );
}