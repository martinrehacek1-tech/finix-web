import { client, queries } from "@/lib/sanity";
import Link from "next/link";
import Image from "next/image";
import { urlFor } from "@/lib/sanity";
import SiteHeader from "@/components/SiteHeader";

export const revalidate = 60;

export default async function BlogIndexPage() {
  const posts = await client.fetch(queries.recentPosts);

  return (
    <main>
      <SiteHeader />
      
      <div className="px-6 py-14 max-w-4xl mx-auto">
        <h1 className="font-serif text-4xl text-brand-navy mb-8">Blog</h1>
        
        <div className="space-y-10">
          {posts.map((post: any) => (
            <article key={post._id} className="flex flex-col md:flex-row gap-6 border-b border-slate-200 pb-10">
              {post.coverImage && (
                <div className="md:w-1/3">
                  <Link href={`/blog/${post.slug.current}`}>
                    <Image
                      src={urlFor(post.coverImage).width(600).url()}
                      alt={post.title}
                      width={600}
                      height={400}
                      className="rounded-xl object-cover w-full aspect-video"
                    />
                  </Link>
                </div>
              )}
              
              <div className="md:w-2/3">
                <p className="text-xs text-brand-teal mb-2">{post.category?.title}</p>
                <Link href={`/blog/${post.slug.current}`} className="block group">
                  <h2 className="font-serif text-2xl text-brand-navy group-hover:text-brand-blue transition">
                    {post.title}
                  </h2>
                </Link>
                <p className="text-slate-600 mt-3 line-clamp-3">{post.excerpt}</p>
                
                <div className="mt-4 flex items-center text-sm text-slate-500">
                  {post.author?.name && <span>{post.author.name}</span>}
                  {post.publishedAt && (
                    <span className="ml-4">
                      {new Date(post.publishedAt).toLocaleDateString("sk-SK")}
                    </span>
                  )}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </main>
  );
}