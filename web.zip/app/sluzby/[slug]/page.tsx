import { client, queries } from "@/lib/sanity";
import ServiceIcon from "@/components/ServiceIcon";
import { PortableText } from "@portabletext/react";
import Link from "next/link";
import { notFound } from "next/navigation";
import SiteHeader from "@/components/SiteHeader";


export const revalidate = 60;

export async function generateStaticParams() {
  const services = await client.fetch(queries.services);
  return services.map((s: any) => ({ slug: s.slug.current }));
}

export default async function ServicePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const service = await client.fetch(queries.serviceBySlug, { slug });

  if (!service) return notFound();

  return (
    <main>
      <SiteHeader />


      <section className="px-6 py-14 max-w-2xl mx-auto text-center">
        <span className="w-16 h-16 rounded-full bg-brand-teal/10 flex items-center justify-center mx-auto mb-5">
          <ServiceIcon name={service.icon} className="w-8 h-8 text-brand-blue" />
        </span>
        <h1 className="font-serif text-3xl text-brand-navy mb-3">{service.title}</h1>
        {service.shortDescription && (
          <p className="text-slate-600 max-w-md mx-auto">{service.shortDescription}</p>
        )}
      </section>

      {service.content && (
        <section className="px-6 pb-14 max-w-2xl mx-auto prose prose-slate prose-sm">
          <PortableText value={service.content} />
        </section>
      )}

      <footer className="bg-brand-navy text-white px-6 py-6 flex items-center justify-between">
        <p className="text-sm">Chcete poradiť ohľadom {service.title.toLowerCase()}?</p>
        <Link href="/kontakt" className="bg-brand-teal text-brand-tealDark text-sm px-4 py-2 rounded-md whitespace-nowrap">
          Dohodnúť stretnutie
        </Link>
      </footer>
    </main>
  );
}